package com.twy.view;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class Upload extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		try {
			 //�õ������ļ���Ŀ¼����ʵ·��
			String storeDirectory = getServletContext().getRealPath("/files");
			//������������
			DiskFileItemFactory factory = new DiskFileItemFactory();
			//�ж��û��ı���enctype�Ƿ���multipart/form-data����
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			if(!isMultipart){
				throw new RuntimeException("û�����ӣ�ǿ���Ķ������ǲ�ס");
			}
			//�������Ľ�������
			ServletFileUpload sfu = new ServletFileUpload(factory);
			List<FileItem> items = sfu.parseRequest(request);
			for(FileItem item:items){
				if(item.isFormField()){
					//��ͨ�ֶ�
					String fieldName = item.getFieldName();//�ֶ���
					String fieldvalue = item.getString();//�ֶ�ֵ
					System.out.println(fieldName+"="+fieldvalue);
				}else{
					//�ϴ��ֶ�:��������
					String fileName = item.getName();//�ϴ��ļ����ļ���   c:\desktop\aaa.txt    aaa.txt
					
					//��ȡ�ļ���
					fileName = fileName.substring(fileName.lastIndexOf("\\")+1);
					
					InputStream in = item.getInputStream();//������
					
					OutputStream out = new FileOutputStream(storeDirectory+"/"+fileName);
					
					int len = -1;
					byte b[] = new byte[1024];
					while((len=in.read(b))!=-1){
						out.write(b, 0, len);
					}
					in.close();
					out.close();
				}
			}
			response.getWriter().write("�ϴ��ɹ�!");
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
